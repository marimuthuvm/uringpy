# Benchmark summary

- experiment: scaling   started (UTC): 2026-10-06T11:11:39+00:00
- repetitions per cell: 1   run length: 5 s   warm-up: 2 s   order: interleaved, shuffled (seed 2010563730)
- load: wrk -t8 -c400 --latency
- client: t2d-standard-8, 8 CPUs, kernel 7.0.0-1011-gcp
- server: t2d-standard-4, 4 CPUs, kernel 7.0.0-1011-gcp, interpreter 3.14.7 gil_on

Throughput is requests/second: mean of the repetitions, with the half-width of the 95% confidence interval (Student t). Scaling is the ratio to the 1-worker cell of the same engine and mode, with its 95% half-width. CPU columns are whole-machine busy %, averaged over runs. GIL is the state the server process reported at start-up.

| engine | mode | workers | GIL | body B | batch cap | n | req/s | ± 95% CI | CV % | scaling | p50 ms | p99 ms | server CPU % | busiest core % | client CPU % | syscalls/req | compl/enter | flags |
| --- | --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| uringpy | thread | 1 | on | 13 | none | 1 | 141,498 | - | - | 1.00× | 2.81 | 3.00 | 28.7 | 95.3 | 33.7 | 0.010 | 218.2 |  |
| uringpy | thread | 4 | on | 13 | none | 1 | 323,731 | - | - | 2.29× | 1.16 | 1.69 | 94.5 | 94.6 | 69.1 | 0.030 | 68.6 |  |
| asyncio | thread | 1 | on | 13 | none | 1 | 67,397 | - | - | 1.00× | 5.87 | 6.42 | 26.2 | 95.5 | 17.3 | - | - |  |
| asyncio | thread | 4 | on | 13 | none | 1 | 34,051 | - | - | 0.51× | 11.44 | 16.24 | 42.8 | 43.1 | 10.9 | - | - |  |
